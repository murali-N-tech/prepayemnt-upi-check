import React, { useState } from "react";
import { amountProblem, describeCap, rupeeInputProps } from "../lib/upiLimits";
import { ShieldCheck, Cpu, Sliders } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function FraudDetection() {
  const { api, username } = useAuth();
  const [merchant, setMerchant] = useState("");
  const [amount, setAmount] = useState("");
  const [deviceScore, setDeviceScore] = useState(0.5);
  const [locationScore, setLocationScore] = useState(0.5);
  const [velocityScore, setVelocityScore] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<any | null>(null);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!merchant.trim() || !amount) {
      setError("Please fill out Merchant and Amount.");
      return;
    }
    // Caught here rather than as a 422 from the backend, which is what used to
    // happen for any amount over the UPI per-transaction cap.
    const badAmount = amountProblem(amount);
    if (badAmount) {
      setError(badAmount);
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    const payload = {
      amount: parseFloat(amount),
      device_score: deviceScore,
      location_score: locationScore,
      velocity_score: velocityScore,
      receiver: merchant.trim(),
      timestamp: new Date().toISOString(),
    };

    try {
      const data = await api<any>("/api/predict", {
        method: "POST",
        body: JSON.stringify(payload),
      });
      setResult(data);
    } catch (err: any) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in" id="fraud-detection-container">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-ink mb-2">Transaction Risk Analysis</h1>
        <p className="text-ink-muted">
          Run high-velocity machine learning transaction scoring models combined with behavioral heuristic rules.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Parameters Form */}
        <div className="bg-surface border border-line rounded-xl p-6 h-fit" id="risk-analysis-form">
          <h2 className="text-xl font-semibold text-ink mb-4">Analyze Transaction</h2>

          <form onSubmit={handleAnalyze} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-ink-muted mb-1">Merchant / Payee</label>
              <input
                type="text"
                value={merchant}
                onChange={(e) => setMerchant(e.target.value)}
                placeholder="e.g. Swiggy"
                required
                className="w-full px-4 py-2 bg-inset border border-line rounded-lg text-ink placeholder-ink-subtle focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-ink-muted mb-1">Amount (INR)</label>
              <input
                {...rupeeInputProps}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={`₹ Amount (max ${describeCap()})`}
                required
                className="w-full px-4 py-2 bg-inset border border-line rounded-lg text-ink placeholder-ink-subtle focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Sliders for advanced biometric metrics */}
            <div className="pt-4 border-t border-line space-y-4">
              <h3 className="text-xs font-semibold text-ink-muted uppercase tracking-wider flex items-center gap-1.5">
                <Sliders className="h-3.5 w-3.5" /> Biometrics & Device Scores
              </h3>

              {/* "Device Trust Score" was backwards: the backend treats this as
                  a RISK score and adds it to the behavioural risk, so a person
                  who set it to 1.00 meaning "this is my own phone" raised the
                  risk by 0.4 instead of lowering it. */}
              <div>
                <div className="flex justify-between text-xs text-ink-muted mb-1">
                  <span>Device risk <span className="text-ink-subtle">(0 = my usual device)</span></span>
                  <span className="text-ink font-semibold">{deviceScore.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={deviceScore}
                  onChange={(e) => setDeviceScore(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-ink-muted mb-1">
                  <span>Location risk <span className="text-ink-subtle">(0 = where I usually pay)</span></span>
                  <span className="text-ink font-semibold">{locationScore.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={locationScore}
                  onChange={(e) => setLocationScore(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-ink-muted mb-1">
                  <span>Velocity count (Same Hour)</span>
                  <span className="text-ink font-semibold">{velocityScore} txs</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="15"
                  step="1"
                  value={velocityScore}
                  onChange={(e) => setVelocityScore(parseInt(e.target.value))}
                  className="w-full accent-indigo-500"
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 text-danger text-sm rounded-lg p-3">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white font-medium rounded-lg shadow-sm transition flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Cpu className="h-4 w-4" />
                  Analyze Transaction
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-2 space-y-6">
          {result ? (
            <div className="space-y-6 animate-fade-in" id="analysis-result">
              {/* Core Risk Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* This card used to read "Risk Score 13 / out of 100" beside a
                    "BLOCKED" verdict, because risk_score is the CALIBRATED
                    PROBABILITY of fraud times 100 while the decision threshold
                    is about 0.13 - the point that holds false positives to 1 in
                    100 at a ~1% base rate. Both numbers were right; showing the
                    score with no threshold beside it made them look like a
                    contradiction. Show what the decision was actually made on. */}
                <div className="bg-surface border border-line rounded-xl p-6 text-center">
                  <span className="text-xs font-semibold text-ink-muted uppercase tracking-wider block">
                    Fraud probability
                  </span>
                  <span className="text-6xl font-black text-ink block mt-2">
                    {result.probability != null
                      ? `${(result.probability * 100).toFixed(1)}%`
                      : result.risk_score}
                  </span>
                  {result.threshold != null && (
                    <span className="text-xs text-ink-subtle block mt-2">
                      flagged at {(result.threshold * 100).toFixed(1)}% — the point that keeps
                      false alarms to {((result.fpr_budget ?? 0.01) * 100).toFixed(0)} in 100
                      good payments
                    </span>
                  )}
                  {result.decided_by && (
                    <span className="text-[11px] text-ink-faint block mt-1">
                      decided by: {result.decided_by}
                    </span>
                  )}
                </div>

                <div className={`border rounded-xl p-6 flex flex-col justify-center items-center ${
                  result.risk === 1
                    ? "bg-rose-500/10 border-rose-500/20 text-danger"
                    : "bg-emerald-500/10 border-emerald-500/20 text-ok"
                }`}>
                  <span className="text-xs font-semibold text-ink-muted uppercase tracking-wider block">Decision Result</span>
                  <span className="text-3xl font-extrabold text-ink block mt-2">
                    {result.risk === 1 ? "BLOCKED / FRAUD" : "APPROVED"}
                  </span>
                  <span className="text-xs text-ink-muted text-center block mt-2 max-w-xs">
                    {result.risk === 1 
                      ? "Transaction flagged as HIGH probability of malicious behaviour." 
                      : "Transaction conforms to standard UPI security guidelines."}
                  </span>
                </div>
              </div>

              {/* Transaction Receipt Details */}
              <div className="bg-surface border border-line rounded-xl p-5 text-sm text-ink-muted">
                <h3 className="font-semibold text-ink mb-3">Transaction Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
                  <div>
                    <span className="text-ink-subtle block">TRANSACTION ID</span>
                    <span className="text-ink font-semibold">{result.transaction_id}</span>
                  </div>
                  <div>
                    <span className="text-ink-subtle block">SENDER</span>
                    <span className="text-ink font-semibold">{username}</span>
                  </div>
                  <div>
                    <span className="text-ink-subtle block">RECEIVER</span>
                    <span className="text-ink font-semibold">{merchant}</span>
                  </div>
                  <div>
                    <span className="text-ink-subtle block">AMOUNT (INR)</span>
                    <span className="text-ink font-semibold">₹{amount}</span>
                  </div>
                </div>
              </div>

              {/* Personalized Assessment Result */}
              {result.personalized_assessment ? (
                <div className="bg-surface border border-line rounded-xl p-6 space-y-4">
                  <h3 className="text-lg font-bold text-ink flex items-center gap-2 border-b border-line pb-3">
                    <ShieldCheck className="h-5 w-5 text-brand" />
                    Personalized Behaviour Assessment
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-inset rounded-lg">
                      <span className="text-xs text-ink-subtle block">Behavior Score</span>
                      <span className="text-2xl font-bold text-ink mt-1">{result.personalized_assessment.risk_score}</span>
                    </div>

                    <div className="p-4 bg-inset rounded-lg">
                      <span className="text-xs text-ink-subtle block">Behavior Level</span>
                      <span className={`text-2xl font-bold mt-1 ${
                        result.personalized_assessment.risk_level === "HIGH" ? "text-danger" : "text-ok"
                      }`}>{result.personalized_assessment.risk_level}</span>
                    </div>
                  </div>

                  <div>
                    <span className="text-xs font-semibold text-ink-muted block mb-2">Behavior Anomalies</span>
                    <ul className="space-y-2">
                      {result.personalized_assessment.reasons.map((r: string, idx: number) => (
                        <li key={idx} className="text-sm text-ink-muted bg-inset/50 p-2.5 rounded border border-line/50">
                          • {r}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ) : (
                <div className="bg-surface/50 border border-line rounded-xl p-5 text-center">
                  <span className="text-xs text-ink-muted block mb-1">Personalized Behavioral Check Not Executed</span>
                  <p className="text-xs text-ink-subtle max-w-md mx-auto">
                    To activate personalized checks, upload a statement on the{" "}
                    <strong className="text-ink-muted">Upload Statement</strong> page.
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-surface/40 border border-line rounded-xl p-12 text-center h-full flex flex-col justify-center items-center">
              <Cpu className="h-16 w-16 text-ink-faint mb-4" />
              <h3 className="text-lg font-semibold text-ink mb-1">Risk Predictor</h3>
              <p className="text-ink-muted max-w-md text-sm">
                Submit a UPI transaction to feed the real-time scoring model and check risk probabilities.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
